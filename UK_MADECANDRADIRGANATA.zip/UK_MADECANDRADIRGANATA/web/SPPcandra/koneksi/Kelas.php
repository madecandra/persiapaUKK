<?php 

    class Kelas
    {
        public function tambah($data)
        {
            global $db;
            $kelas = $data['kelas'];
            $kompetensikeahlian = $data['kompetensi_keahlian'];

            $query = "CALL InsertKelas('$kelas', '$kompetensikeahlian')";
            mysqli_query($db, $query);
            return mysqli_affected_rows($db);
        }

        public function edit($data)
        {
            global $db;
            $idkelas = $data['id_kelas'];
            $kelas = $data['kelas'];
            $kompetensikeahlian = $data['kompetensi_keahlian'];

            $query = "UPDATE kelas SET kelas = '$kelas', kompetensi_keahlian = '$kompetensikeahlian' WHERE id_kelas = '$idkelas'";
            mysqli_query($db, $query);
            return mysqli_affected_rows($db);
        }

        public function hapus($data)
        {
            global $db;
            $idkelas = $data['id_kelas'];

            $query = "DELETE FROM kelas WHERE id_kelas = '$idkelas' ";
            mysqli_query($db, $query);
            return mysqli_affected_rows($db);
        }
    }

?>