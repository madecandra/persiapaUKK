<?php 

    class Pembayaran
    {
        public function tambah($data)
        {
            global $db;
            $tahun_ajaran = $data['tahun_ajaran'];
            $nominal = $data['nominal'];

            $query = "CALL InsertPembayaran ('$tahun_ajaran', '$nominal')";
            mysqli_query($db, $query);
            return mysqli_affected_rows($db);
        }

        public function edit($data)
        {
            global $db;
            $idpembayaran = $data['id_pembayaran'];
            $tahunajaran = $data['tahun_ajaran'];
            $nominal = $data['nominal'];

            $query = "UPDATE pembayaran SET tahun_ajaran = '$tahunajaran', nominal = '$nominal' WHERE id_pembayaran = '$idpembayaran'";
            mysqli_query($db, $query);
            return mysqli_affected_rows($db);
        }

        public function hapus($data)
        {
            global $db;
            $idpembayaran = $data['id_pembayaran'];

            $query = "DELETE FROM pembayaran WHERE id_pembayaran = '$idpembayaran' ";
            mysqli_query($db, $query);
            return mysqli_affected_rows($db);
        }
    }

?>