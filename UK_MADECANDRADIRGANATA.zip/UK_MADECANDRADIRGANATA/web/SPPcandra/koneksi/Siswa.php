<?php 

    class Siswa
    {
        public function tambah($data)
        {
            global $db;
            $nisn = $data['nisn'];
            $nis = $data['nis'];
            $nama = $data['nama'];
            $alamat = $data['alamat'];
            $telepon = $data['telepon'];
            $idkelas = $data['id_kelas'];
            $idpengguna = $data['id_pengguna'];
            $idpembayaran = $data['id_pembayaran'];

            $query = "INSERT INTO siswa VALUES (null, '$nisn', '$nis', '$nama', '$alamat','$telepon', '$idkelas', '$idpengguna', '$idpembayaran')";
            mysqli_query($db, $query);
            return mysqli_affected_rows($db);
        }

        public function edit($data)
        {
            global $db;
            $idsiswa = $data['id_siswa'];
            $nisn = $data['nisn'];
            $nis = $data['nis'];
            $nama = $data['nama'];
            $alamat = $data['alamat'];
            $telepon = $data['telepon'];
            $idkelas = $data['id_kelas'];
            $idpengguna = $data['id_pengguna'];
            $idpembayaran = $data['id_pembayaran'];

            $query = "UPDATE siswa SET nisn = '$nisn', nis = '$nis', nama = '$nama', alamat = '$alamat', telepon = '$telepon', id_kelas = '$idkelas', id_pengguna = '$idpengguna', id_pembayaran = '$idpembayaran'  WHERE id_siswa = '$idsiswa'";
            mysqli_query($db, $query);
            return mysqli_affected_rows($db);
        }

        public function hapus($data)
        {
            global $db;
            $id_siswa = $data['id_siswa'];

            $query = "DELETE FROM siswa WHERE id_siswa = '$id_siswa' ";
            mysqli_query($db, $query);
            return mysqli_affected_rows($db);
        }
    }

?>