<?php 

    class Pengguna
    {
        public function tambah($data)
        {
            global $db;
            $username = $data['username'];
            $password = $data['password'];
            $role = $data['role'];

            $query = "INSERT INTO pengguna VALUES (null, '$username', '$password', '$role')";
            mysqli_query($db, $query);
            return mysqli_affected_rows($db);
        }

        public function edit($data)
        {
            global $db;
            $idpengguna = $data['id_pengguna'];
            $username = $data['username'];
            $password = $data['password'];
            $role = $data['role'];

            $query = "UPDATE pengguna SET username = '$username', password = '$password', role = '$role' WHERE id_pengguna = '$idpengguna'";
            mysqli_query($db, $query);
            return mysqli_affected_rows($db);
        }

        public function hapus($data)
        {
            global $db;
            $idpengguna = $data['id_pengguna'];

            $query = "DELETE FROM pengguna WHERE id_pengguna = '$idpengguna' ";
            mysqli_query($db, $query);
            return mysqli_affected_rows($db);
        }
    }

?>