<?php 

    class Petugas
    {
        public function tambah($data)
        {
            global $db;
            $nama = $data['nama'];
            $idpengguna = $data['id_pengguna'];

            $query = "CALL InsertPetugas ('$nama', '$idpengguna')";
            mysqli_query($db, $query);
            return mysqli_affected_rows($db);
        }

        public function edit($data)
        {
            global $db;
            $idpetugas = $data['id_petugas'];
            $nama = $data['nama'];
            $idpengguna = $data['id_pengguna'];

            $query = "UPDATE petugas SET nama = '$nama', id_pengguna = '$idpengguna' WHERE id_petugas = '$idpetugas'";
            mysqli_query($db, $query);
            return mysqli_affected_rows($db);
        }

        public function hapus($data)
        {
            global $db;
            $idpetugas = $data['id_petugas'];

            $query = "DELETE FROM petugas WHERE id_petugas = '$idpetugas' ";
            mysqli_query($db, $query);
            return mysqli_affected_rows($db);
        }
    }

?>