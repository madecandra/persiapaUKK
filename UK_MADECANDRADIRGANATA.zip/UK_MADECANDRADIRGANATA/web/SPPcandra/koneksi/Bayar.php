<?php
include '../koneksi/Login.php';
class Transaksi extends Login
{
    public function create($data)
    {
        $tahun = date('Y');
        $siswa = $data['id_siswa'];
        $pembayaran = $data['id_pembayaran'];
        $petugas = $_SESSION['id_petugas'];
        $bulan_bayar = $data['bulan_bayar'];

        var_dump($data);
        
        foreach ($data['bulan_bayar'] as $bulan) {
            $query = "INSERT INTO transaksi(id_transaksi, tanggal_bayar, bulan_bayar, tahun_bayar, id_siswa, id_pembayaran, id_petugas) VALUES (null, NOW(), $bulan, $tahun, 9, $pembayaran, 13)";
            mysqli_query($this->conn, $query);
        }
        return mysqli_affected_rows($this->conn);
    }
}
