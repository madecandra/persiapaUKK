<?php
session_unset();
session_destroy();

header('Location: ../SPPcandra/index.php')


?>