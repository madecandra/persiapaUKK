<?php 
$db = mysqli_connect("localhost", "root", "", "ukkcandra");
include "../koneksi/Petugas.php";

$Petugas = new Petugas();
if(isset($_GET['id_petugas'])){
    if ( $Petugas->hapus($_GET) > 0 ) {
        header ("Location: ../admin/dataPetugas.php");
    }
}
