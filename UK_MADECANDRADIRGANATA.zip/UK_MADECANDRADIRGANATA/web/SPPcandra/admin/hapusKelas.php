<?php 
$db = mysqli_connect("localhost", "root", "", "ukkcandra");
include "../koneksi/Kelas.php";

$kelas = new Kelas();
if(isset($_GET['id_kelas'])){
    if ( $kelas->hapus($_GET) > 0 ) {
        header ("Location: ../admin/dataKelas.php");
    }
}
