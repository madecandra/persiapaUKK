<?php 
$db = mysqli_connect("localhost", "root", "", "ukkcandra");
include "../koneksi/Siswa.php";

$Siswa = new Siswa();
if(isset($_GET['id_siswa'])){
    if ( $Siswa->hapus($_GET) > 0 ) {
        header ("Location: ../admin/dataSiswa.php");
    }
}
