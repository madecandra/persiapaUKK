<?php 
$db = mysqli_connect("localhost", "root", "", "ukkcandra");
include "../koneksi/Pengguna.php";

$Pengguna = new Pengguna();
if(isset($_GET['id_pengguna'])){
    if ( $Pengguna->hapus($_GET) > 0 ) {
        header ("Location: ../admin/dataPengguna.php");
    }
}
