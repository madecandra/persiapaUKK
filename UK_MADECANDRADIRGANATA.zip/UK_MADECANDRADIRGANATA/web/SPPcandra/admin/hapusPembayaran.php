<?php 
$db = mysqli_connect("localhost", "root", "", "ukkcandra");
include "../koneksi/Pembayaran.php";

$pembayaran = new Pembayaran();
if(isset($_GET['id_pembayaran'])){
    if ( $pembayaran->hapus($_GET) > 0 ) {
        header ("Location: ../admin/dataPembayaran.php");
    }
}
