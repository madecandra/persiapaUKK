-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 15, 2023 at 07:06 AM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ukkcandra`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertKelas` (IN `in_kelas` VARCHAR(255), IN `in_kompetensi_keahlian` VARCHAR(255))   BEGIN
INSERT INTO kelas VALUES (null, in_kelas, in_kompetensi_keahlian);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertPembayaran` (IN `in_tahun_ajaran` VARCHAR(9), IN `in_nominal` INT)   BEGIN
INSERT INTO pembayaran VALUES (null, in_tahun_ajaran, in_nominal);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertPengguna` (IN `in_username` VARCHAR(255), IN `in_password` VARCHAR(255), IN `role` INT)   BEGIN
INSERT INTO pengguna VALUES (null, in_username, in_password, in_role);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertPetugas` (IN `in_nama` VARCHAR(50), IN `in_id_pengguna` INT)   BEGIN
INSERT INTO petugas VALUES (null, in_nama, in_id_pengguna);
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `kelas`
--

CREATE TABLE `kelas` (
  `id_kelas` int NOT NULL,
  `kelas` varchar(255) NOT NULL,
  `kompetensi_keahlian` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `kelas`
--

INSERT INTO `kelas` (`id_kelas`, `kelas`, `kompetensi_keahlian`) VALUES
(35, 'X', 'Multimedia'),
(36, 'XI', 'Teknik Komputer Dan Jaringan'),
(37, 'XII', 'Rekayasa Perangkat Lunak');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_pembayaran` int NOT NULL,
  `tahun_ajaran` varchar(9) NOT NULL,
  `nominal` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`id_pembayaran`, `tahun_ajaran`, `nominal`) VALUES
(1, '2021', 1500000),
(2, '2022', 1700000),
(3, '2023', 1200000);

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `id_pengguna` int NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `username`, `password`, `role`) VALUES
(27, 'petugas', '123', 2),
(28, 'candra', '321', 3),
(31, 'admin', 'admin', 1),
(32, 'candra3', '1234', 3);

-- --------------------------------------------------------

--
-- Table structure for table `petugas`
--

CREATE TABLE `petugas` (
  `id_petugas` int NOT NULL,
  `nama` varchar(50) NOT NULL,
  `id_pengguna` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `petugas`
--

INSERT INTO `petugas` (`id_petugas`, `nama`, `id_pengguna`) VALUES
(13, 'made gede', 27),
(14, 'made ', 28);

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE `siswa` (
  `id_siswa` int NOT NULL,
  `nisn` varchar(24) NOT NULL,
  `nis` char(6) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `telepon` varchar(24) NOT NULL,
  `id_kelas` int NOT NULL,
  `id_pengguna` int NOT NULL,
  `id_pembayaran` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`id_siswa`, `nisn`, `nis`, `nama`, `alamat`, `telepon`, `id_kelas`, `id_pengguna`, `id_pembayaran`) VALUES
(9, '0000000002', '00002', 'made candra dirganata', 'Jln. Wibisana', '123454', 37, 28, 3),
(10, '0000000002', '289', 'Santi Nareswari', 'Jln. Tunjung Biru No. 12', '123454', 37, 28, 3);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int NOT NULL,
  `tanggal_bayar` datetime NOT NULL,
  `bulan_bayar` int NOT NULL,
  `tahun_bayar` int NOT NULL,
  `id_siswa` int NOT NULL,
  `id_petugas` int NOT NULL,
  `id_pembayaran` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `tanggal_bayar`, `bulan_bayar`, `tahun_bayar`, `id_siswa`, `id_petugas`, `id_pembayaran`) VALUES
(11, '2023-03-15 03:22:43', 3, 2023, 9, 13, 3),
(12, '2023-04-28 11:23:08', 4, 2023, 9, 14, 3),
(13, '2023-03-15 14:46:09', 7, 2023, 9, 13, 3),
(14, '2023-03-15 14:46:09', 10, 2023, 9, 13, 3),
(16, '2023-03-15 14:47:17', 5, 2023, 9, 13, 3),
(17, '2023-03-15 14:49:17', 8, 2023, 9, 13, 3),
(18, '2023-03-15 14:49:30', 9, 2023, 9, 13, 3),
(19, '2023-03-15 14:49:50', 1, 2023, 9, 13, 3),
(20, '2023-03-15 14:50:36', 11, 2023, 9, 13, 3),
(21, '2023-03-15 14:51:58', 2, 2023, 9, 13, 3),
(22, '2023-03-15 14:56:21', 6, 2023, 9, 13, 3),
(23, '2023-03-15 14:57:17', 12, 2023, 9, 13, 3);

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_pengguna`
-- (See below for the actual view)
--
CREATE TABLE `v_pengguna` (
`id_pengguna` int
,`username` varchar(255)
,`password` varchar(255)
,`role` int
,`id_siswa` int
,`id_petugas` int
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_petugas`
-- (See below for the actual view)
--
CREATE TABLE `v_petugas` (
`id_petugas` int
,`nama` varchar(50)
,`id_pengguna` int
,`role` int
,`username` varchar(255)
,`password` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_siswa`
-- (See below for the actual view)
--
CREATE TABLE `v_siswa` (
`id_siswa` int
,`nisn` varchar(24)
,`nis` char(6)
,`nama` varchar(255)
,`alamat` text
,`telepon` varchar(24)
,`id_kelas` int
,`id_pengguna` int
,`id_pembayaran` int
,`kelas` varchar(255)
,`kompetensi_keahlian` varchar(255)
,`username` varchar(255)
,`password` varchar(255)
,`role` int
,`tahun_ajaran` varchar(9)
,`nominal` int
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_transaksi`
-- (See below for the actual view)
--
CREATE TABLE `v_transaksi` (
`tanggal_bayar` datetime
,`bulan_bayar` int
,`tahun_bayar` int
,`id_siswa` int
,`id_transaksi` int
,`nisn` varchar(24)
,`nis` char(6)
,`nama` varchar(255)
,`alamat` text
,`telepon` varchar(24)
,`tahun_ajaran` varchar(9)
,`nominal` int
);

-- --------------------------------------------------------

--
-- Structure for view `v_pengguna`
--
DROP TABLE IF EXISTS `v_pengguna`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_pengguna`  AS SELECT `pengguna`.`id_pengguna` AS `id_pengguna`, `pengguna`.`username` AS `username`, `pengguna`.`password` AS `password`, `pengguna`.`role` AS `role`, `siswa`.`id_siswa` AS `id_siswa`, `petugas`.`id_petugas` AS `id_petugas` FROM ((`pengguna` left join `siswa` on((`pengguna`.`id_pengguna` = `siswa`.`id_pengguna`))) left join `petugas` on((`pengguna`.`id_pengguna` = `petugas`.`id_pengguna`)))  ;

-- --------------------------------------------------------

--
-- Structure for view `v_petugas`
--
DROP TABLE IF EXISTS `v_petugas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_petugas`  AS SELECT `petugas`.`id_petugas` AS `id_petugas`, `petugas`.`nama` AS `nama`, `petugas`.`id_pengguna` AS `id_pengguna`, `pengguna`.`role` AS `role`, `pengguna`.`username` AS `username`, `pengguna`.`password` AS `password` FROM (`petugas` join `pengguna` on((`petugas`.`id_pengguna` = `pengguna`.`id_pengguna`)))  ;

-- --------------------------------------------------------

--
-- Structure for view `v_siswa`
--
DROP TABLE IF EXISTS `v_siswa`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_siswa`  AS SELECT `siswa`.`id_siswa` AS `id_siswa`, `siswa`.`nisn` AS `nisn`, `siswa`.`nis` AS `nis`, `siswa`.`nama` AS `nama`, `siswa`.`alamat` AS `alamat`, `siswa`.`telepon` AS `telepon`, `siswa`.`id_kelas` AS `id_kelas`, `siswa`.`id_pengguna` AS `id_pengguna`, `siswa`.`id_pembayaran` AS `id_pembayaran`, `kelas`.`kelas` AS `kelas`, `kelas`.`kompetensi_keahlian` AS `kompetensi_keahlian`, `pengguna`.`username` AS `username`, `pengguna`.`password` AS `password`, `pengguna`.`role` AS `role`, `pembayaran`.`tahun_ajaran` AS `tahun_ajaran`, `pembayaran`.`nominal` AS `nominal` FROM (((`siswa` left join `kelas` on((`siswa`.`id_kelas` = `kelas`.`id_kelas`))) left join `pengguna` on((`siswa`.`id_pengguna` = `pengguna`.`id_pengguna`))) left join `pembayaran` on((`siswa`.`id_pembayaran` = `pembayaran`.`id_pembayaran`)))  ;

-- --------------------------------------------------------

--
-- Structure for view `v_transaksi`
--
DROP TABLE IF EXISTS `v_transaksi`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_transaksi`  AS SELECT `transaksi`.`tanggal_bayar` AS `tanggal_bayar`, `transaksi`.`bulan_bayar` AS `bulan_bayar`, `transaksi`.`tahun_bayar` AS `tahun_bayar`, `siswa`.`id_siswa` AS `id_siswa`, `transaksi`.`id_transaksi` AS `id_transaksi`, `siswa`.`nisn` AS `nisn`, `siswa`.`nis` AS `nis`, `siswa`.`nama` AS `nama`, `siswa`.`alamat` AS `alamat`, `siswa`.`telepon` AS `telepon`, `pembayaran`.`tahun_ajaran` AS `tahun_ajaran`, `pembayaran`.`nominal` AS `nominal` FROM ((`transaksi` left join `siswa` on((`transaksi`.`id_siswa` = `siswa`.`id_siswa`))) left join `pembayaran` on((`transaksi`.`id_pembayaran` = `pembayaran`.`id_pembayaran`)))  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`id_kelas`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id_pembayaran`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_pengguna`);

--
-- Indexes for table `petugas`
--
ALTER TABLE `petugas`
  ADD PRIMARY KEY (`id_petugas`),
  ADD KEY `id_pengguna` (`id_pengguna`);

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id_siswa`),
  ADD KEY `id_kelas` (`id_kelas`),
  ADD KEY `id_pengguna` (`id_pengguna`),
  ADD KEY `id_pembayaran` (`id_pembayaran`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `id_siswa` (`id_siswa`),
  ADD KEY `id_petugas` (`id_petugas`),
  ADD KEY `id_pembayaran` (`id_pembayaran`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kelas`
--
ALTER TABLE `kelas`
  MODIFY `id_kelas` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id_pembayaran` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_pengguna` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `petugas`
--
ALTER TABLE `petugas`
  MODIFY `id_petugas` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `siswa`
--
ALTER TABLE `siswa`
  MODIFY `id_siswa` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `petugas`
--
ALTER TABLE `petugas`
  ADD CONSTRAINT `petugas_ibfk_1` FOREIGN KEY (`id_pengguna`) REFERENCES `pengguna` (`id_pengguna`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `siswa`
--
ALTER TABLE `siswa`
  ADD CONSTRAINT `siswa_ibfk_1` FOREIGN KEY (`id_kelas`) REFERENCES `kelas` (`id_kelas`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `siswa_ibfk_2` FOREIGN KEY (`id_pembayaran`) REFERENCES `pembayaran` (`id_pembayaran`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `siswa_ibfk_3` FOREIGN KEY (`id_pengguna`) REFERENCES `pengguna` (`id_pengguna`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`id_siswa`) REFERENCES `siswa` (`id_siswa`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `transaksi_ibfk_2` FOREIGN KEY (`id_petugas`) REFERENCES `petugas` (`id_petugas`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `transaksi_ibfk_3` FOREIGN KEY (`id_pembayaran`) REFERENCES `pembayaran` (`id_pembayaran`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
